package com.example.v0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
